// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Allocate relay"); }
int main(){
  announce();
  return lionss_run_workload("TurnRelay");
}
