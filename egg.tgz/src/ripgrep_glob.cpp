// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Glob-filtered grep");
  std::fflush(stdout);
  return lionss_run_workload("ripgrep_glob");
}
