// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Reconstruct control flow"); }
int main(){
  announce();
  return lionss_run_workload("relooperCfg");
}
