// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Model coldspring flow\n", stdout);
  return lionss_run_workload("coldspring");
}
